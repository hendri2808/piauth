<!DOCTYPE html>
<html>
    <head>
        <script src="https://sdk.minepi.com/pi-sdk.js"></script>
        <script>Pi.init({ version: "2.0", sandbox: true })</script>
    </head>
<body>
    <h1>PI Payment Sandbox Mode</h1>
    <?php 
    echo 'Dev For SDK PI Network<br>';
    
    $curl = curl_init();

    curl_setopt_array($curl, array(
      CURLOPT_URL => "https://api.minepi.com/v2/me",
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => "",
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => "GET",
      CURLOPT_POSTFIELDS =>"\n\n",
      CURLOPT_HTTPHEADER => array(
        "Accept: application/json",
        "Content-Type: application/json",
        "Authorization:Key dooy87a1oeim324mq3erryvnxw2mwp2egteeq2jvfaieafwog2gbbmydarvmye1t"
      ),gd
    ));
    
    $response = curl_exec($curl);
    
    curl_close($curl);
    echo 'Response : '.$response;

?>
 <script>


 </script>

</body>
</html>
